#pragma once
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS

#include <WinSock2.h>
#include <stdlib.h>
#include <stdio.h>
#include <thread>
#include <vector>
#pragma comment(lib "Ws2_32.lib")

#define BUFSIZE 512
